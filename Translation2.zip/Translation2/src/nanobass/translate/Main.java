package nanobass.translate;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import com.badlogic.gdx.files.FileHandle;

import localization.ILanguageFile;
import localization.LanguageRegistry;
import localization.TranslationEntry;
import localization.TranslationKey;
import localization.TranslationLocale;
import localization.files.CosmicReachLanguageFile;

public class Main {

	public static void main(String[] args) {

		for (File file : new File("assets/lang").listFiles()) {
			if (file.isDirectory())
				continue;
			FileHandle handle = new FileHandle(file);
			try {
				ILanguageFile lang = CosmicReachLanguageFile.loadLanguageFile(handle);
				LanguageRegistry.registerLanguageFile(lang);
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		LanguageRegistry.selectLanguage(TranslationLocale.fromLanguageTag("de-DE"));

		for (Map.Entry<TranslationKey, TranslationEntry> entry : LanguageRegistry.selectedLanguage.getFile().all().entrySet()) {
			System.out.println(entry.getKey().getIdentifier() + " = " + entry.getValue().string().string());
		}

	}

}
