package localization;

import java.util.HashMap;
import java.util.Map;

import localization.files.MergedLanguageFile;

public class LanguageRegistry {

	public static final Map<TranslationLocale, ILanguageFile> allLanguageFiles = new HashMap<>();

	public static final Map<TranslationLocale, Language> allLanguages = new HashMap<>();

	public static Language selectedLanguage;

	public static void selectLanguage(TranslationLocale locale) {
		if (allLanguages.get(locale) instanceof Language newLanguage) {
			selectedLanguage = newLanguage;
		} else {
			System.err.println(locale);
		}
	}

	public static void registerLanguageFile(ILanguageFile lang) {
		TranslationLocale locale = lang.locale();

		if (allLanguageFiles.containsKey(locale) && allLanguageFiles.get(locale) instanceof MergedLanguageFile merged) {
			merged.addLanguageFile(lang);
		} else {
			MergedLanguageFile merged = new MergedLanguageFile(locale);
			merged.addLanguageFile(lang);
			allLanguageFiles.put(locale, merged);
		}

		if (!allLanguages.containsKey(locale)) {
			Language language = new Language(allLanguageFiles.get(locale));
			allLanguages.put(locale, language);
		}
	}

}
